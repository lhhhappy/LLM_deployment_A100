set -euo pipefail
cd /sjtu/linhang/arena/repo
scripts/pod/ppush /tmp/ax/staging/queue-20260924T130948-28858 build/queue/queue-20260924T130948-28858
source scripts/pod/common.sh
bexec 'python3 /tmp/ax/staging/queue-20260924T130948-28858/build/queue/queue-20260924T130948-28858/queue_bundle.py publish /tmp/ax/staging/queue-20260924T130948-28858/build/queue/queue-20260924T130948-28858'
