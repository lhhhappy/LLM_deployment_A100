# 055: formal A -> A+171+172 -> A, isolated HTTP cost screen on real TP8 weights.
# This combined arm measures the combination only. Numerical cause remains open.
# No SLO, capability or equivalence verdict; no trace synchronization during timing.
G_NAME=off_a_kernelref
G_PATCHES="000-interface-compliance.patch 101-role-boundary-split.patch 106-defer-chunk-on-no-kv.patch 110-sm80-dsa-indexer.patch 111-sm80-fp8-moe-marlin.patch 114-indexer-row-shard.patch 120-sched-protect-chain.patch 121-sched-cap-while-decoding.patch 130-async-tokenize.patch 140-kda-dual-snapshot.patch 150-startup-warmup.patch 160-nextn-sm80.patch 170-glm-bcg-prefill.patch"
G_ARGS="--kv-cache-dtype bfloat16 --linear-attn-backend triton --linear-attn-verify-backend triton --speculative-algorithm NEXTN --speculative-draft-model-path /mnt/models --speculative-num-steps 3 --speculative-eagle-topk 1 --speculative-num-draft-tokens 4 --max-running-requests 32 --cuda-graph-max-bs 32 --prefill-decode-interval 2"
G_ENV="SGLANG_AX_KDA_DUAL_SNAPSHOT=0 SGLANG_AX_SCHED_PROTECT=1 SGLANG_AX_SCHED_SHORT_TOKENS=8192 SGLANG_AX_ASYNC_TOKENIZE=0 SGLANG_MAMBA_SSM_DTYPE=float32 SGLANG_OPT_FUSED_KDA_VERIFY=0 SGLANG_AX_INDEXER_ROW_SHARD=1 SGLANG_AX_SCHED_COLD_CAP=4096"

source "$AX/bin/scripts/pod/lib.sh"
ROOT_RUN=$RUN_DIR
BASE_PATCHES=$G_PATCHES
export SGLANG_ARENA_ROLE_BOUNDARY_TOKEN_IDS=154827,154829 SGLANG_OPT_DEEPGEMM_HC_PRENORM=0
export $G_ENV
unset SGLANG_AX_PACE_TPOT SGLANG_AX_NUMTRACE_DIR SGLANG_AX_NUMTRACE_DUMP_LAYER
echo "08eee808be8632776721c90769162a3a30622b8e73fd806565a0c94cdb10026e  $AX/patches/171-kda-bf16-proj-fusion.patch" | sha256sum -c - || exit 2
echo "2752e70a32a732294b6025bd13ad6226c269c885c25fb96800885da5b669d606  $AX/patches/172-moe-clamped-swiglu.patch" | sha256sum -c - || exit 2
echo "a6c792211631544dd66a001e1825bbff96dd1e5bc549dbb7195db086ad42ac03  $AX/verify_kit/kernel_combo_cost.py" | sha256sum -c - || exit 2
for arm in ref1 combo ref2; do
  export RUN_DIR="$ROOT_RUN/$arm"
  mkdir -p "$RUN_DIR" || exit 2
  case "$arm" in
    ref*) G_NAME=off_a_kernelref; G_PATCHES=$BASE_PATCHES; unset SGLANG_AX_KDA_FUSE_PROJ SGLANG_AX_MOE_FUSE_SWIGLU ;;
    combo) G_NAME=off_a_combo171172; G_PATCHES="$BASE_PATCHES 171-kda-bf16-proj-fusion.patch 172-moe-clamped-swiglu.patch";
      export SGLANG_AX_KDA_FUSE_PROJ=1 SGLANG_AX_MOE_FUSE_SWIGLU=1 ;;
  esac
  prepare_src "$G_NAME" $G_PATCHES || exit 2
  ( cd "$AX/patches" && sha256sum $G_PATCHES ) | sed 's/^/PATCH_SHA /'
  ensure_engine "$G_NAME" --schedule-policy lpm --dsa-prefill-backend tilelang --dsa-decode-backend tilelang $G_ARGS || exit 3
  python3 - "$RUN_DIR/server.log" <<'PYREADY'
import pathlib,sys,time
path=pathlib.Path(sys.argv[1]);deadline=time.monotonic()+300
while time.monotonic()<deadline:
    if 'The server is fired up and ready to roll!' in path.read_text():break
    time.sleep(1)
else:raise RuntimeError('native startup warmup did not finish')
PYREADY
  [ "$?" = 0 ] || exit 3
  curl -sf "http://127.0.0.1:$PORT/get_server_info" > "$RUN_DIR/server_info.json" || exit 3
  nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv > "$RUN_DIR/gpu_memory_before.csv" || exit 3
  grep -E 'max_total_num_tokens|KV Cache is allocated|ax-kda171' "$RUN_DIR/server.log" > "$RUN_DIR/startup_evidence.log" || exit 3
  if [ "$arm" = combo ]; then
    [ "$(grep -c 'ax-kda171.*fused=True' "$RUN_DIR/server.log")" -ge 34 ] || { echo KDA_FUSION_NOT_OBSERVED; exit 4; }
  fi
  python3 "$AX/verify_kit/kernel_combo_cost.py" "$RUN_DIR/cost" > "$RUN_DIR/cost.log" 2>&1 || { tail -30 "$RUN_DIR/cost.log"; exit 5; }
  tail -3 "$RUN_DIR/cost.log"
  # Separate path receipt after timing; profiler samples never enter cost data.
  if [ "$arm" = combo ]; then
python3 - "$RUN_DIR" "$PORT" <<'PYPROFILE'
import gzip, json, re, sys, urllib.request
from pathlib import Path
root, port = Path(sys.argv[1]), sys.argv[2]
trace_dir = root / 'path-profile'
trace_dir.mkdir(exist_ok=True)
def post(path, data):
    req = urllib.request.Request(f'http://127.0.0.1:{port}' + path,
                                 json.dumps(data).encode(), {'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=900) as resp:
        return resp.read()
post('/flush_cache', {})
post('/start_profile', {'output_dir': str(trace_dir), 'activities': ['CPU', 'GPU'],
                        'with_stack': False, 'record_shapes': False, 'profile_id': 'combo171172_path'})
try:
    body = {'text': 'Explain how a compiler schedules independent instructions. ' * 128,
            'sampling_params': {'max_new_tokens': 1, 'temperature': 0, 'ignore_eos': True}}
    (trace_dir / 'request-result.json').write_bytes(post('/generate', body))
finally:
    (trace_dir / 'stop-response.txt').write_bytes(post('/stop_profile', {}))
counts = {}
for path in trace_dir.glob('*.json.gz'):
    match = re.search(r'TP-(\d+)', path.name)
    if not match:
        continue
    with gzip.open(path, 'rt') as handle:
        events = json.load(handle)['traceEvents']
    counts[int(match[1])] = sum(e.get('cat') == 'kernel' and
                                '_ax172_clamped_swiglu' in e.get('name', '') for e in events)
(trace_dir / 'kernel-counts.json').write_text(json.dumps(counts, indent=2) + '\n')
print('FUSED_KERNEL_COUNTS', counts)
if set(counts) != set(range(8)) or not all(counts.values()):
    raise RuntimeError('172 fused kernel not observed on every TP rank')
PYPROFILE
[ "$?" = 0 ] || exit 9
  fi
  nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv > "$RUN_DIR/gpu_memory_after.csv" || exit 3
done
python3 - "$ROOT_RUN" <<'PYCOMPARE'
import json,pathlib,sys
root=pathlib.Path(sys.argv[1]);summaries=[json.loads((root/arm/'cost/summary.json').read_text()) for arm in ('ref1','combo','ref2')]
assert all(x['status']=='COST_SCREEN_COMPLETE' and x['repeats']==3 for x in summaries)
assert all(len(x['cases'])==8 for x in summaries)
rows=[]
for a,b,c in zip(*(x['cases'] for x in summaries)):
    keys=['input_tokens','batch','output_tokens','prompt_sha256']
    assert all(a[k]==b[k]==c[k] for k in keys)
    assert all(len(x['samples_s'])==3 and all(t>0 for t in x['samples_s']) for x in (a,b,c))
    row={k:a[k] for k in keys}
    row.update(ref1_s=a['median_s'],combo_s=b['median_s'],ref2_s=c['median_s'],
        baseline_repeat_change=c['median_s']/a['median_s']-1,
        reduction_vs_ref1=1-b['median_s']/a['median_s'],reduction_vs_ref2=1-b['median_s']/c['median_s'])
    rows.append(row);print(json.dumps(row),flush=True)
(root/'comparison.json').write_text(json.dumps({'status':'COST_SCREEN_COMPLETE','cases':rows,
    'scope':'Isolated real TP8 HTTP cost; includes scheduler/transport/MTP. No SLO/equivalence/capability claim.'},indent=2)+'\n')
PYCOMPARE
[ "$?" = 0 ] || exit 6
echo 'COMBINED_COST_SCREEN_COMPLETE: review cost, output fingerprints and memory; numerical verification still open'
