import importlib.util
from typing import Optional, Tuple, Union

import torch

from sglang.kernels.ops.attention import kda_fused_decode
from sglang.kernels.ops.mamba.causal_conv1d_triton import (
    causal_conv1d_fn,
    causal_conv1d_update,
)
from sglang.srt.environ import envs
from sglang.srt.layers.attention.hybrid_linear_attn_backend import MambaAttnBackendBase
from sglang.srt.layers.attention.linear.kernels.kda_flashinfer import (
    build_fused_accept_indices,
)
from sglang.srt.layers.attention.linear.kernels.kda_triton import TritonKDAKernel
from sglang.srt.layers.attention.linear.utils import (
    LinearAttnKernelBackend,
    build_verify_intermediate_state_indices,
)
from sglang.srt.layers.radix_linear_attention import RadixLinearAttention
from sglang.srt.utils import get_bool_env_var, is_cpu, is_cuda, is_npu
from sglang.srt.utils.common import rank0_log

# KDA always uses the triton causal_conv1d_fn (no CUDA override).
# Only causal_conv1d_update needs platform-specific overrides for decode.
if is_npu():
    from sgl_kernel_npu.mamba.causal_conv1d import causal_conv1d_update_npu

    causal_conv1d_update = causal_conv1d_update_npu
elif is_cpu():
    from sgl_kernel.mamba import causal_conv1d_update_cpu

    causal_conv1d_update = causal_conv1d_update_cpu

from sglang.srt.model_executor.forward_batch_info import ForwardBatch, ForwardMode
from sglang.srt.model_executor.model_runner import ModelRunner
from sglang.srt.runtime_context import (
    get_disagg,
    get_exec,
    get_memory,
    get_parallel,
    get_spec,
)


_AX_KDA_PREFILL_CPU_LENGTH = get_bool_env_var(
    "SGLANG_AX_KDA_PREFILL_CPU_LENGTH", "false"
)


def _ax_kda_cpu_logical_tokens(forward_batch, query_start_loc, *, attn_cp_size=1):
    """Prototype of the CPU-length part of upstream SGLang #39688.

    The host list is the source of extend_seq_lens and its prefix sum. Unlike
    extend_num_tokens, it retains logical lengths when inputs are padded.
    Keep TBO's parent-relative offsets and unvalidated CP layouts on the old
    path. CP metadata may be populated after backend metadata initialization,
    so the already initialized parallel configuration is also required.
    Decode/verify graphs use separate metadata and are unchanged.
    """
    if forward_batch.forward_mode not in (ForwardMode.EXTEND, ForwardMode.MIXED):
        return None
    if getattr(forward_batch, "tbo_parent_token_range", None) is not None:
        return None
    if attn_cp_size != 1 or getattr(forward_batch, "attn_cp_metadata", None) is not None:
        return None
    lengths = forward_batch.extend_seq_lens_cpu
    if (
        not isinstance(lengths, (list, tuple))
        or len(lengths) != forward_batch.batch_size
        or query_start_loc is None
        or query_start_loc.shape != (len(lengths) + 1,)
        or any(type(length) is not int or length < 0 for length in lengths)
    ):
        return None
    return sum(lengths)


def _ax_kda_resolve_logical_tokens(metadata, physical_num_tokens):
    if _AX_KDA_PREFILL_CPU_LENGTH:
        count = getattr(metadata, "_ax_cpu_logical_num_tokens", None)
        if type(count) is int and 0 <= count <= physical_num_tokens:
            return count
    return int(metadata.query_start_loc[-1])


class KDAKernelDispatcher:
    """Dispatches KDA kernel calls to the appropriate backend per mode."""

    def __init__(
        self,
        decode_backend: LinearAttnKernelBackend,
        prefill_backend: LinearAttnKernelBackend,
        verify_backend: LinearAttnKernelBackend,
    ):
        self.verify_backend = verify_backend
        triton_kernel = TritonKDAKernel()
        self.triton_kernel = triton_kernel
        helion_kernel = None
        if decode_backend.is_helion() or prefill_backend.is_helion():
            if not is_cuda():
                raise ValueError("KDA Helion backend requires CUDA")
            from sglang.srt.layers.attention.linear.kernels.kda_helion import (
                HelionKDAKernel,
            )

            helion_kernel = HelionKDAKernel(
                triton_fallback=triton_kernel,
                enable_decode=decode_backend.is_helion(),
                enable_prefill=prefill_backend.is_helion(),
            )

        if decode_backend.is_triton():
            self.decode_kernel = triton_kernel
        elif decode_backend.is_helion():
            assert helion_kernel is not None
            self.decode_kernel = helion_kernel
        elif decode_backend.is_cutedsl():
            if not is_cuda():
                raise ValueError("KDA CuTe DSL backend requires CUDA")
            from sglang.srt.layers.attention.linear.kernels.kda_cutedsl import (
                CuteDSLKDAKernel,
            )

            self.decode_kernel = CuteDSLKDAKernel()
        elif decode_backend.is_flashinfer():
            # FlashInfer recurrent_kda: SM100 decode + MTP (target_verify).
            # Prefill stays on Triton / CuTe DSL (FlashInfer has no KDA chunk kernel).
            if not is_cuda():
                raise ValueError("KDA FlashInfer backend requires CUDA")
            from sglang.srt.layers.attention.linear.kernels.kda_flashinfer import (
                FlashInferKDAKernel,
            )

            self.decode_kernel = FlashInferKDAKernel()
        else:
            raise ValueError(
                f"Unsupported KDA decode backend: {decode_backend}. "
                "KDA supports 'triton', 'helion', 'cutedsl', or 'flashinfer'."
            )

        # target_verify kernel, selected via --linear-attn-verify-backend (defaults
        # to follow decode: flashinfer -> recurrent_kda, else triton).
        #   triton: fused chain + tree (retrieve_parent_token) verify; the reference
        #     the KDA correctness tests assert against.
        #   flashinfer: recurrent_kda (SM100, chain only); reuses the decode kernel
        #     when decode is also flashinfer.
        #   nv_cutedsl: fused Kimi-K3/DSpARK dense verify.
        if verify_backend.is_triton():
            self.verify_kernel = triton_kernel
        elif verify_backend.is_flashinfer():
            if decode_backend.is_flashinfer():
                self.verify_kernel = self.decode_kernel
            else:
                if not is_cuda():
                    raise ValueError("KDA FlashInfer verify backend requires CUDA")
                from sglang.srt.layers.attention.linear.kernels.kda_flashinfer import (
                    FlashInferKDAKernel,
                )

                self.verify_kernel = FlashInferKDAKernel()
        elif verify_backend.is_nv_cutedsl():
            self.verify_kernel = triton_kernel
        elif verify_backend.is_custom():
            # Future custom KDA verify kernel plugs in here.
            raise NotImplementedError(
                "--linear-attn-verify-backend custom: no custom KDA verify kernel "
                "is registered yet."
            )
        else:
            raise ValueError(
                f"Unsupported KDA verify backend: {verify_backend}. "
                "KDA verify supports 'triton', 'nv_cutedsl', or 'flashinfer'."
            )

        if prefill_backend.is_triton():
            self.extend_kernel = triton_kernel
        elif prefill_backend.is_helion():
            assert helion_kernel is not None
            self.extend_kernel = helion_kernel
        elif prefill_backend.is_flashkda():
            from sglang.srt.layers.attention.linear.kernels.kda_flashkda import (
                FlashKDAKernel,
            )

            self.extend_kernel = FlashKDAKernel()
        elif prefill_backend.is_cutedsl():
            if not is_cuda():
                raise ValueError("KDA CuTe DSL backend requires CUDA")
            from sglang.srt.layers.attention.linear.kernels.kda_cutedsl import (
                CuteDSLKDAKernel,
            )

            cutedsl_kernel = CuteDSLKDAKernel()
            if cutedsl_kernel.supports_prefill:
                # SM100 chunk prefill pipeline.
                self.extend_kernel = cutedsl_kernel
            else:
                # CuTe DSL prefill kernels need SM100 (Blackwell); on older GPUs
                # fall back to the Triton chunk kernel.
                self.extend_kernel = triton_kernel
                rank0_log(
                    "KDA cutedsl prefill needs SM100; falling back to Triton extend."
                )
        elif prefill_backend.is_ptx_kda():
            if not is_cuda():
                raise ValueError("PTX KDA prefill backend requires CUDA")
            from sglang.srt.layers.attention.linear.kernels.kda_ptx import PtxKDAKernel

            ptx_kda_kernel = PtxKDAKernel()
            if ptx_kda_kernel.supports_prefill:
                self.extend_kernel = ptx_kda_kernel
            else:
                self.extend_kernel = triton_kernel
                rank0_log(
                    "PTX KDA prefill needs SM103 (GB300); falling back to Triton "
                    "extend."
                )
        elif prefill_backend.is_nvidia_kda():
            if not is_cuda():
                raise ValueError("NVIDIA KDA prefill backend requires CUDA")
            from sglang.srt.layers.attention.linear.kernels.kda_nvidia import (
                NvidiaKDAKernel,
            )

            nvidia_kda_kernel = NvidiaKDAKernel()
            if nvidia_kda_kernel.supports_prefill:
                self.extend_kernel = nvidia_kda_kernel
            else:
                self.extend_kernel = triton_kernel
                rank0_log(
                    "NVIDIA KDA prefill needs SM100; falling back to Triton extend."
                )
        else:
            raise ValueError(
                f"Unsupported KDA prefill backend: {prefill_backend}. "
                "KDA supports 'triton', 'helion', 'flashkda', 'cutedsl', "
                "'nvidia_kda', or 'ptx_kda' (cutedsl/nvidia_kda prefill need "
                "SM100, ptx_kda SM103)."
            )

        self.supports_packed_decode = getattr(
            self.decode_kernel, "supports_packed_decode", False
        )

        rank0_log(
            f"KDA kernel dispatcher: decode={self.decode_kernel.__class__.__name__}, "
            f"verify={self.verify_kernel.__class__.__name__}, "
            f"extend={self.extend_kernel.__class__.__name__} "
            f"packed_decode={self.supports_packed_decode}"
        )

    def packed_decode(
        self,
        mixed_qkv: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
        *,
        A_log: torch.Tensor,
        dt_bias: torch.Tensor,
        scale: float,
        ssm_states: torch.Tensor,
        cache_indices: torch.Tensor,
        num_v_heads: int,
        head_v_dim: int,
        **kwargs,
    ) -> Optional[torch.Tensor]:
        """Attempt packed decode. Returns output tensor or None if the decode
        kernel does not support packed decode."""
        if not self.supports_packed_decode:
            return None
        return self.decode_kernel.packed_decode(
            mixed_qkv,
            a,
            b,
            A_log=A_log,
            dt_bias=dt_bias,
            scale=scale,
            ssm_states=ssm_states,
            cache_indices=cache_indices,
            num_v_heads=num_v_heads,
            head_v_dim=head_v_dim,
            **kwargs,
        )

    def decode(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
        *,
        A_log: torch.Tensor,
        dt_bias: torch.Tensor,
        ssm_states: torch.Tensor,
        cache_indices: torch.Tensor,
        query_start_loc: torch.Tensor,
        lower_bound: Optional[float] = None,
        **kwargs,
    ) -> torch.Tensor:
        if lower_bound is not None and not isinstance(
            self.decode_kernel, TritonKDAKernel
        ):
            raise NotImplementedError(
                f"lower_bound (safe gate) is only supported by TritonKDAKernel; "
                f"got {self.decode_kernel.__class__.__name__}."
            )
        return self.decode_kernel.decode(
            q,
            k,
            v,
            a,
            b,
            A_log=A_log,
            dt_bias=dt_bias,
            ssm_states=ssm_states,
            cache_indices=cache_indices,
            query_start_loc=query_start_loc,
            lower_bound=lower_bound,
            **kwargs,
        )

    def target_verify(
        self,
        A_log: torch.Tensor,
        dt_bias: torch.Tensor,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
        *,
        ssm_states: torch.Tensor,
        cache_indices: torch.Tensor,
        query_start_loc: torch.Tensor,
        intermediate_states_buffer: torch.Tensor,
        intermediate_state_indices: torch.Tensor,
        cache_steps: int,
        retrieve_parent_token: Optional[torch.Tensor],
        lower_bound: Optional[float] = None,
        **kwargs,
    ) -> torch.Tensor:
        """MTP / speculative-decode verify, routed to ``self.verify_kernel``
        (FlashInfer decode -> recurrent_kda; Triton / CuTe DSL decode -> the Triton
        fused KDA verify)."""
        if lower_bound is not None and not isinstance(
            self.verify_kernel, TritonKDAKernel
        ):
            raise NotImplementedError(
                "lower_bound (safe gate) target verify is only supported by "
                f"TritonKDAKernel; got {self.verify_kernel.__class__.__name__}."
            )
        return self.verify_kernel.target_verify(
            A_log=A_log,
            dt_bias=dt_bias,
            q=q,
            k=k,
            v=v,
            a=a,
            b=b,
            ssm_states=ssm_states,
            cache_indices=cache_indices,
            query_start_loc=query_start_loc,
            intermediate_states_buffer=intermediate_states_buffer,
            intermediate_state_indices=intermediate_state_indices,
            cache_steps=cache_steps,
            retrieve_parent_token=retrieve_parent_token,
            lower_bound=lower_bound,
            # Forward extras (e.g. the fused ring-write cache_ring/replayssm_*).
            **kwargs,
        )

    def extend(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        g: torch.Tensor,
        beta: torch.Tensor,
        *,
        ssm_states: torch.Tensor,
        cache_indices: torch.Tensor,
        query_start_loc: torch.Tensor,
        **kwargs,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        kernel = self.extend_kernel
        if kwargs.get("snapshot_offsets") is not None:
            kernel = self.triton_kernel
        if kwargs.get("lower_bound") is not None and not getattr(
            kernel, "supports_safe_gate", True
        ):
            kernel = self.triton_kernel
        return kernel.extend(
            q,
            k,
            v,
            g,
            beta,
            ssm_states=ssm_states,
            cache_indices=cache_indices,
            query_start_loc=query_start_loc,
            **kwargs,
        )


def ragged_verify_dense_scatter_indices(
    *,
    query_start_loc: torch.Tensor,
    seq_len: int,
    draft_token_num: int,
) -> torch.Tensor:
    """Dense [bs, draft_token_num] slot index per packed ragged-verify token.

    Rows never exceed draft_token_num under either layout variant (cap for
    graph replay, planner construction for eager -- see
    RaggedVerifyLayout.padded_to_bucket), so in-row offsets stay in-row;
    tokens past the layout's coverage collapse into one ghost row at index
    bs * draft_token_num.
    """
    batch_size = query_start_loc.shape[0] - 1
    token_pos = torch.arange(seq_len, device=query_start_loc.device, dtype=torch.int32)
    token_slots = torch.searchsorted(query_start_loc[1:], token_pos, right=True)
    return (
        token_slots * draft_token_num
        + (token_pos - query_start_loc[token_slots]).to(torch.int64)
    ).clamp_(max=batch_size * draft_token_num)


class KDAAttnBackend(MambaAttnBackendBase):
    """Attention backend for KDA (Kimi Delta Attention) linear attention."""

    # The verify kernel is varlen and the conv path scatters ragged tokens
    # to its dense layout, so ragged verify graphs are supported.
    supports_ragged_verify_graph: bool = True

    # Candidate states remain isolated until acceptance, so target metadata may load
    # on the MTP plan stream.
    supports_overlap_plan_stream_graph_load: bool = True

    # KDA gets graph padding explicitly and never uses ReplaySSM's host-seqlen
    # force-flush path.
    needs_cpu_seq_lens: bool = False

    def __init__(self, model_runner: ModelRunner):
        super().__init__(model_runner)
        # Needed by the extra_buffer track path: _init_track_conv_indices reads
        # conv_states_shape[-1] as the conv window length (kernel_size - 1).
        # The KDA pool stores conv states as [kernel-1, dim] — transposed vs
        # Mamba2/GDN's [dim, kernel-1] — so expose the transposed shape here.
        self.conv_states_shape = (
            model_runner.req_to_token_pool.mamba_pool.mamba_cache.conv[0]
            .transpose(-1, -2)
            .shape
        )
        backends = model_runner.linear_attn_backends
        decode_backend = backends.decode
        prefill_backend = backends.prefill
        verify_backend = backends.verify
        # KDA FlashInfer target_verify (recurrent_kda) is chain-only (no tree-ancestor
        # traversal). Reject EAGLE tree verify (topk > 1) early at setup, keyed on the
        # verify backend (not decode). The kernel keeps a per-call
        # retrieve_parent_token backstop that also covers ngram tree.
        speculative_topk = get_spec().speculative_eagle_topk or 1
        if verify_backend.is_flashinfer() and speculative_topk > 1:
            raise ValueError(
                "KDA FlashInfer speculative decoding only supports topk=1 "
                "(EAGLE tree verify / retrieve_parent_token is unsupported)."
            )
        self.kernel_dispatcher = KDAKernelDispatcher(
            decode_backend, prefill_backend, verify_backend
        )
        # Warm only the selected prefill implementation, before graph capture.
        # The same Triton object can also be an unused fallback for other backends.
        if self.kernel_dispatcher.extend_kernel is self.kernel_dispatcher.triton_kernel:
            armed = self.kernel_dispatcher.triton_kernel.arm_prefill_prepare(
                model_runner.device
            )
            if armed:
                rank0_log("[ax] KDA prefill prepare: sm80 bf16 T=8192/16384 H=8 D=128")
            state_armed = self.kernel_dispatcher.triton_kernel.arm_prefill_state(
                model_runner.device
            )
            if state_armed:
                rank0_log("[ax] KDA prefill state: sm80 BV16 T=8192/16384 N<=3")
        # One-shot; emitted at the first fused-decode interception below.
        self._fused_override_notice = (
            "K3 fused KDA decode engaged: --linear-attn-decode-backend "
            f"{decode_backend} only picks the fallback kernel for shapes "
            "the fused kernel does not cover."
        )
        self._fused_chain_verify_fn = None
        if (
            envs.SGLANG_OPT_FUSED_KDA_VERIFY.get()
            and verify_backend.is_triton()
            and self.kernel_dispatcher.verify_kernel.supports_fused_chain_verify
        ):
            from sglang.kernels.ops.attention.fla.fused_kda_conv_recurrent_verify import (
                fused_kda_conv_gating_verify,
            )

            self._fused_chain_verify_fn = fused_kda_conv_gating_verify
            rank0_log("KDA fused chain-verify kernel enabled (topk==1 path).")
        # Per-request row index into the speculative `intermediate_ssm` scratch,
        # used by the MTP / target_verify path (mirrors GDNAttnBackend). Sized
        # past the pool for attn_tp-padded warmup/MLP-sync batches (see helper).
        self.verify_intermediate_state_indices = (
            build_verify_intermediate_state_indices(
                self.req_to_token_pool.size,
                model_runner.device,
            )
        )
        # Fused-accept spec path (flashinfer recurrent_kda): the next verify
        # seeds itself in-kernel from the accepted checkpoint slot
        # (num_accepted_tokens), so the per-round SSM commit scatter is skipped.
        # accept_lens_pool holds last round's accept length per mamba slot;
        # extend stages fresh requests with 1 (read slot 0). Its presence is the
        # signal that switches the post-verify commit to conv-only.
        if self._can_fuse_accept_state(verify_backend):
            self.accept_lens_pool = torch.ones(
                self.req_to_token_pool.size + 1,
                dtype=torch.int32,
                device=model_runner.device,
            )

    @staticmethod
    def _can_fuse_accept_state(verify_backend) -> bool:
        """Whether the verify kernel can seed itself from the accepted checkpoint.

        The seed comes from recurrent_kda's ``num_accepted_tokens``, which makes
        the previous round's accepted state addressable in-kernel so the SSM
        state never has to round-trip through the committed pool (`temporal`).
        Hence the keying on the verify backend -- the one that selects the
        target_verify kernel -- and not on decode, which is set separately.

        `temporal` then goes stale between verifies, which is what the remaining
        conditions rule out: each is a reader of the committed state that the
        skipped scatter would starve. Falling short of the contract falls back to
        the commit scatter rather than raising -- this is a capability, not a
        mode. Every condition reads its namespace bag rather than the record:
        these are fields resolution decides, so the record would answer with
        what the operator typed instead of what was decided.
        """
        if not verify_backend.is_flashinfer():
            return False  # only recurrent_kda takes num_accepted_tokens
        if get_spec().speculative_algorithm is None:
            return False  # no verify round, and no intermediate scratch
        if not get_memory().disable_radix_cache:
            return False  # mamba radix tracking snapshots `temporal`
        if get_exec().mamba.enable_linear_replayssm_spec:
            return False  # the ring already owns the verify-round commitment
        if get_disagg().disaggregation_mode != "null":
            return False  # the PD hand-off transfers `temporal`
        return True

    def _fused_accept_indices(
        self,
        *,
        cache_indices: torch.Tensor,
        query_start_loc: torch.Tensor,
        intermediate_state_cache: torch.Tensor,
        draft_token_num: int,
    ):
        """Slot-indexed verify rows + accept lengths for this forward.

        Every KDA layer of a forward verifies the same requests over the same
        draft window, so the build is hoisted onto the shared forward metadata:
        layer 0 builds, the rest reuse. Under cuda graph the capture then holds
        a single build reading the static slot buffer, instead of one per layer.
        """
        metadata = self.forward_metadata
        if metadata.fused_accept_state_indices is None:
            batch_size = query_start_loc.shape[0] - 1
            (
                metadata.fused_accept_state_indices,
                metadata.fused_accept_num_accepted,
            ) = build_fused_accept_indices(
                slots=cache_indices[:batch_size],
                scratch_steps=intermediate_state_cache.shape[1],
                draft_token_num=draft_token_num,
                accept_lens_pool=self.accept_lens_pool,
            )
        return (
            metadata.fused_accept_state_indices,
            metadata.fused_accept_num_accepted,
        )

    def init_forward_metadata(self, forward_batch: ForwardBatch):
        super().init_forward_metadata(forward_batch)
        if _AX_KDA_PREFILL_CPU_LENGTH:
            # Compute once per live batch, not once per KDA layer. Keep this
            # experiment local to KDA rather than extending shared metadata.
            self.forward_metadata._ax_cpu_logical_num_tokens = (
                _ax_kda_cpu_logical_tokens(
                    forward_batch,
                    self.forward_metadata.query_start_loc,
                    attn_cp_size=get_parallel().attn_cp_size,
                )
            )
        if self.forward_metadata.has_mamba_track_mask:
            self.forward_metadata.mamba_track_mask_indices = (
                forward_batch.mamba_track_mask.nonzero(as_tuple=True)[0]
            )
            self.forward_metadata.conv_states_mask_indices = (
                forward_batch.mamba_track_indices[
                    self.forward_metadata.mamba_track_mask_indices
                ]
            )

    def forward_decode(
        self,
        layer: RadixLinearAttention,
        forward_batch: ForwardBatch,
        mixed_qkv: Union[torch.Tensor, Tuple[torch.Tensor, ...]],
        a: torch.Tensor,
        b: torch.Tensor,
        **kwargs,
    ):
        layer_cache = self.req_to_token_pool.mamba2_layer_cache(layer.layer_id)
        conv_states = layer_cache.conv[0]
        ssm_states = layer_cache.temporal
        query_start_loc = self.forward_metadata.query_start_loc
        cache_indices = self.forward_metadata.mamba_cache_indices

        # ReplaySSM is mostly a GDN bandwidth optimization. It remains wired for
        # KDA correctness paths, but packed decode is faster for KDA today.
        replayssm_write_pos = getattr(
            self.forward_metadata, "replayssm_write_pos", None
        )
        replayssm_force_flush = getattr(
            self.forward_metadata, "replayssm_force_flush", None
        )
        replayssm_d = layer_cache.replayssm_d
        replayssm_k = layer_cache.replayssm_k
        replayssm_g = layer_cache.replayssm_g

        # Fully fused decode step: conv1d update + delta-rule recurrence +
        # gated RMSNorm in one kernel. Engages only when the model handed off
        # the output-norm gate for this forward (attempt-and-verify stash,
        # see kimi_k3.py) and the shapes are covered; the model applies the
        # norm itself whenever the stash is left unconsumed.
        if replayssm_d is None:
            fused_static = getattr(layer, "_k3_fused_decode_args", None)
            onorm_gate = getattr(layer, "_k3_onorm_gate", None)
            if (
                fused_static is not None
                and onorm_gate is not None
                and mixed_qkv.shape[0] == cache_indices.shape[0]
                and b.ndim == 3
                and kda_fused_decode.covered(
                    mixed_qkv,
                    a,
                    b[0],
                    conv_states,
                    ssm_states,
                    cache_indices,
                    onorm_gate,
                )
            ):
                if self._fused_override_notice is not None:
                    rank0_log(self._fused_override_notice)
                    self._fused_override_notice = None
                w_q_t, w_k_t, w_v_t, conv_bias, a_log, onorm_w, onorm_eps = fused_static
                core_attn_out = kda_fused_decode.kda_fused_decode(
                    mixed_qkv,
                    a,
                    b[0],
                    conv_states,
                    w_q_t,
                    w_k_t,
                    w_v_t,
                    conv_bias,
                    a_log,
                    layer.dt_bias,
                    onorm_gate,
                    onorm_w,
                    ssm_states,
                    cache_indices,
                    scale=layer.head_k_dim**-0.5,
                    onorm_eps=onorm_eps,
                    lower_bound=layer.lower_bound,
                )
                layer._k3_onorm_consumed = True
                self._track_mamba_state_decode(
                    forward_batch,
                    conv_states,
                    ssm_states,
                    cache_indices,
                    layer.layer_id,
                )
                return core_attn_out
            elif fused_static is not None and onorm_gate is not None:
                # One-shot diagnostics: the model offered the handoff but the
                # runtime shapes were rejected (decode stays on the unfused
                # chain, which is correct but slower).
                if not getattr(KDAAttnBackend, "_fused_reject_logged", False):
                    KDAAttnBackend._fused_reject_logged = True
                    rank0_log(
                        "KDA fused decode rejected by covered(): "
                        f"mixed_qkv {tuple(mixed_qkv.shape)}/{mixed_qkv.dtype} "
                        f"stride {mixed_qkv.stride()}, "
                        f"conv_states {tuple(conv_states.shape)} "
                        f"stride {conv_states.stride()}, "
                        f"ssm_states {tuple(ssm_states.shape)}/{ssm_states.dtype}, "
                        f"b {tuple(b.shape)}, indices {cache_indices.dtype}"
                    )

        qkv = causal_conv1d_update(
            mixed_qkv,
            conv_states.transpose(-1, -2),
            layer.conv_weights,
            layer.bias,
            activation="silu",
            conv_state_indices=cache_indices,
        )

        # The packed kernel assumes one token per request.
        if (
            self.kernel_dispatcher.supports_packed_decode
            and getattr(layer, "lower_bound", None) is None
        ):
            assert qkv.shape[0] == cache_indices.shape[0], (
                "KDA packed decode requires one token per sequence (T=1): "
                f"got {qkv.shape[0]} tokens for {cache_indices.shape[0]} requests."
            )
            core_attn_out = self.kernel_dispatcher.packed_decode(
                mixed_qkv=qkv,
                a=a,
                b=b,
                A_log=layer.A_log,
                dt_bias=layer.dt_bias,
                scale=layer.head_k_dim**-0.5,
                ssm_states=ssm_states,
                cache_indices=cache_indices,
                num_v_heads=layer.num_v_heads,
                head_v_dim=layer.head_v_dim,
                lower_bound=layer.lower_bound,
                replayssm_d=replayssm_d,
                replayssm_k=replayssm_k,
                replayssm_g=replayssm_g,
                replayssm_write_pos=replayssm_write_pos,
                replayssm_force_flush=replayssm_force_flush,
            )
            self._track_mamba_state_decode(
                forward_batch, conv_states, ssm_states, cache_indices, layer.layer_id
            )
            return core_attn_out

        q, k, v = qkv.split([layer.q_dim, layer.k_dim, layer.v_dim], dim=-1)
        q = q.unflatten(-1, (-1, layer.head_q_dim)).unsqueeze(0)  # n (h d) -> 1 n h d
        k = k.unflatten(-1, (-1, layer.head_k_dim)).unsqueeze(0)  # n (h d) -> 1 n h d
        v = v.unflatten(-1, (-1, layer.head_v_dim)).unsqueeze(0)  # n (h d) -> 1 n h d

        core_attn_out = self.kernel_dispatcher.decode(
            q=q,
            k=k,
            v=v,
            a=a,
            b=b,
            A_log=layer.A_log,
            dt_bias=layer.dt_bias,
            ssm_states=ssm_states,
            cache_indices=cache_indices,
            query_start_loc=query_start_loc,
            lower_bound=layer.lower_bound,
        )

        self._track_mamba_state_decode(
            forward_batch, conv_states, ssm_states, cache_indices, layer.layer_id
        )

        return core_attn_out

    def forward_extend(
        self,
        layer: RadixLinearAttention,
        forward_batch: ForwardBatch,
        mixed_qkv: Union[torch.Tensor, Tuple[torch.Tensor, ...]],
        a: torch.Tensor,
        b: torch.Tensor,
        **kwargs,
    ):
        # MTP / speculative-decode verify is a multi-token-per-seq path with
        # per-step state checkpointing + central rollback; handled separately.
        if forward_batch.forward_mode.is_target_verify():
            return self._forward_target_verify(layer, forward_batch, mixed_qkv, a, b)

        query_start_loc = self.forward_metadata.query_start_loc
        cache_indices = self.forward_metadata.mamba_cache_indices

        mamba_cache_params = self.req_to_token_pool.mamba2_layer_cache(layer.layer_id)
        conv_states = mamba_cache_params.conv[0].transpose(-1, -2)

        ssm_states = mamba_cache_params.temporal

        # Normal extend path
        if forward_batch.extend_prefix_lens is None:
            raise RuntimeError(
                "extend_prefix_lens cannot be None in non-TARGET_VERIFY mode."
            )
        has_initial_state = forward_batch.extend_prefix_lens > 0

        physical_num_tokens = mixed_qkv.shape[0]
        logical_num_tokens = _ax_kda_resolve_logical_tokens(
            self.forward_metadata, physical_num_tokens
        )
        if logical_num_tokens < physical_num_tokens:
            mixed_qkv = mixed_qkv[:logical_num_tokens]
            a = a[:, :logical_num_tokens]
            b = b[:, :logical_num_tokens]

        snapshot_offsets = forward_batch.ax_kda_snapshot_offsets
        snapshot_slots = forward_batch.ax_kda_snapshot_slots
        if snapshot_offsets is not None:
            from sglang.kernels.ops.attention.fla.kda_snapshot import store_conv

            assert ssm_states.dtype == torch.float32
            store_conv(mixed_qkv, mamba_cache_params.conv[0], query_start_loc,
                       snapshot_offsets, snapshot_slots)
        if self.forward_metadata.has_mamba_track_mask and snapshot_offsets is None:
            # Snapshot the conv sliding window at the last track-aligned chunk
            # boundary into the ping-pong track slots (the prefix-cache restore
            # source). The KDA pool stores conv states as [kernel-1, dim], so
            # rows of the raw [tokens, dim] pre-conv input index in directly
            # (GDN needs a transpose here; KDA does not).
            mamba_cache_params.conv[0][
                self.forward_metadata.conv_states_mask_indices
            ] = mixed_qkv[self.forward_metadata.track_conv_indices]

        # Depthwise conv is channel-independent, so one packed call over the
        # full qkv width matches the decode path and saves two kernel launches.
        qkv = causal_conv1d_fn(
            mixed_qkv.transpose(0, 1),
            layer.conv_weights,
            layer.bias,
            activation="silu",
            conv_states=conv_states,
            has_initial_state=has_initial_state,
            cache_indices=cache_indices,
            query_start_loc=query_start_loc,
            seq_lens_cpu=forward_batch.extend_seq_lens_cpu,
        ).transpose(0, 1)
        q, k, v = qkv.split([layer.q_dim, layer.k_dim, layer.v_dim], dim=-1)

        q = q.unflatten(-1, (-1, layer.head_q_dim)).unsqueeze(0)  # n (h d) -> 1 n h d
        k = k.unflatten(-1, (-1, layer.head_k_dim)).unsqueeze(0)  # n (h d) -> 1 n h d
        v = v.unflatten(-1, (-1, layer.head_v_dim)).unsqueeze(0)  # n (h d) -> 1 n h d

        gate_was_flat = a.ndim == 3
        if gate_was_flat:
            a = a.unflatten(-1, (-1, layer.head_k_dim))

        track_ssm = self.forward_metadata.has_mamba_track_mask and snapshot_offsets is None
        core_attn_out = self.kernel_dispatcher.extend(
            q=q,
            k=k,
            v=v,
            g=a,
            beta=b,
            ssm_states=ssm_states,
            cache_indices=cache_indices,
            query_start_loc=query_start_loc,
            A_log=layer.A_log,
            dt_bias=layer.dt_bias,
            lower_bound=layer.lower_bound,
            beta_is_raw=gate_was_flat,
            extend_seq_lens_cpu=forward_batch.extend_seq_lens_cpu,
            # draft_extend_v2 must stay rollback-able, so kernels that commit state
            # in place (e.g. FlashKDA) must not run for it.
            is_spec_decode=forward_batch.forward_mode.is_draft_extend_v2(),
            return_intermediate_states=track_ssm,
            snapshot_offsets=snapshot_offsets,
            snapshot_slots=snapshot_slots,
            # Which global chunk rows of h the track snapshot will read; lets
            # kernels that cannot materialize per-chunk states (NVIDIA KDA) take the
            # fast path when the snapshot only needs the final state.
            track_ssm_h_src=(
                self.forward_metadata.track_ssm_h_src if track_ssm else None
            ),
        )
        if track_ssm:
            # Snapshot the SSM state at the last track-aligned chunk boundary
            # from the kernel's per-chunk states (h) / final states into the
            # ping-pong track slots (see _init_track_ssm_indices).
            core_attn_out, h = core_attn_out
            self._track_mamba_state_extend(
                forward_batch, h, ssm_states, self.forward_metadata
            )

        if logical_num_tokens < physical_num_tokens:
            pad = core_attn_out.new_zeros(
                (1, physical_num_tokens - logical_num_tokens)
                + tuple(core_attn_out.shape[2:])
            )
            core_attn_out = torch.cat((core_attn_out, pad), dim=1)

        if (
            self.accept_lens_pool is not None
            and not forward_batch.forward_mode.is_draft_extend_v2()
        ):
            # Fused-accept staging: the extend kernel just wrote this request's
            # committed state; copy it into scratch slot 0 and reset the accept
            # length to 1 so the first verify reads slot 0. Runs once per KDA
            # layer (the nat write is idempotent; the scratch copy is per-layer).
            slots = cache_indices.to(torch.int64)
            intermediate_ssm = mamba_cache_params.intermediate_ssm
            intermediate_ssm[slots, 0] = ssm_states[slots].to(intermediate_ssm.dtype)
            self.accept_lens_pool[slots] = 1

        return core_attn_out

    def _forward_target_verify(
        self,
        layer: RadixLinearAttention,
        forward_batch: ForwardBatch,
        mixed_qkv: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
    ):
        """MTP / speculative-decode verify (topk=1), mirroring the GDN backend.

        Conv1d runs per draft token with intermediate-window checkpointing; the
        SSM verify kernel writes each draft token's post-state into the
        speculative `intermediate_ssm` scratch so the central post-verify rollback
        (update_mamba_state_after_mtp_verify) can commit the accepted-length state.
        """
        fm = self.forward_metadata
        seq_len = mixed_qkv.shape[0]
        query_start_loc = fm.query_start_loc
        cache_indices = fm.mamba_cache_indices
        retrieve_next_token = fm.retrieve_next_token
        retrieve_next_sibling = fm.retrieve_next_sibling
        retrieve_parent_token = fm.retrieve_parent_token

        mamba_cache_params = self.req_to_token_pool.mamba2_layer_cache(layer.layer_id)
        conv_states = mamba_cache_params.conv[0]
        ssm_states = mamba_cache_params.temporal
        intermediate_state_cache = getattr(mamba_cache_params, "intermediate_ssm", None)
        # ReplaySSM: intermediate_ssm is intentionally None (the ring + commit-time
        # fold replace the per-step snapshots). Pass None to the verify kernel so it
        # skips the write (CACHE_INTERMEDIATE_STATES=False); the output is unaffected.
        replayssm_rawv = getattr(mamba_cache_params, "replayssm_rawv", None)
        replayssm_on = replayssm_rawv is not None
        if intermediate_state_cache is None and not replayssm_on:
            raise RuntimeError(
                "KDA target_verify requires a speculative mamba cache "
                "(MambaPool.SpeculativeState); none found."
            )
        intermediate_conv_window_cache = mamba_cache_params.intermediate_conv_window[0]
        intermediate_state_indices = self.verify_intermediate_state_indices

        draft_token_num = forward_batch.spec_info.draft_token_num
        ragged_layout = forward_batch.spec_info.ragged_verify_layout
        if self._can_run_dspark_cutedsl_mtp(
            layer=layer,
            mixed_qkv=mixed_qkv,
            a=a,
            b=b,
            draft_token_num=draft_token_num,
            ragged_layout=ragged_layout,
            conv_states=conv_states,
            ssm_states=ssm_states,
            intermediate_state_cache=intermediate_state_cache,
            intermediate_conv_window_cache=intermediate_conv_window_cache,
            retrieve_parent_token=retrieve_parent_token,
            replayssm_rawv=replayssm_rawv,
        ):
            return self._run_dspark_cutedsl_mtp(
                layer=layer,
                mixed_qkv=mixed_qkv,
                a=a,
                b=b,
                conv_states=conv_states,
                ssm_states=ssm_states,
                intermediate_state_cache=intermediate_state_cache,
                intermediate_conv_window_cache=intermediate_conv_window_cache,
                intermediate_state_indices=intermediate_state_indices,
                cache_indices=cache_indices,
                query_start_loc=query_start_loc,
                replayssm_rawv=replayssm_rawv,
                replayssm_rawk=mamba_cache_params.replayssm_rawk,
                replayssm_g=mamba_cache_params.replayssm_g,
                replayssm_beta=mamba_cache_params.replayssm_beta,
            )
        if ragged_layout is None:
            batch_size = seq_len // draft_token_num
            conv_state_indices = cache_indices[:batch_size]
            # Fused chain-verify fast path: one kernel replaces the transpose-copy +
            # conv1d + transpose-copy + recurrence sequence. Chain (topk==1) only --
            # retrieve_* are None there; the tree path and any unsupported shape keep
            # the reference kernels.
            if self._can_run_fused_chain_verify(
                layer=layer,
                mixed_qkv=mixed_qkv,
                a=a,
                b=b,
                draft_token_num=draft_token_num,
                conv_states=conv_states,
                ssm_states=ssm_states,
                intermediate_state_cache=intermediate_state_cache,
                intermediate_conv_window_cache=intermediate_conv_window_cache,
                cache_indices=conv_state_indices,
                intermediate_state_indices=intermediate_state_indices[:batch_size],
                retrieve_next_token=retrieve_next_token,
                retrieve_next_sibling=retrieve_next_sibling,
                retrieve_parent_token=retrieve_parent_token,
                replayssm_rawv=replayssm_rawv,
            ):
                return self._fused_chain_verify_fn(
                    mixed_qkv=mixed_qkv,
                    conv_weight=layer.conv_weights,
                    conv_bias=layer.bias,
                    # Same [.., dim, width] view the reference causal_conv1d_update
                    # call below takes: upstream stores the persistent conv state
                    # width-major, and the kernel asserts the dim axis is
                    # contiguous. (intermediate_conv_window is transposed on both
                    # the fork and upstream, so it needs no extra adjustment.)
                    conv_state=conv_states.transpose(-1, -2),
                    conv_state_indices=conv_state_indices,
                    intermediate_conv_window=(
                        intermediate_conv_window_cache.transpose(-1, -2)
                    ),
                    intermediate_state_indices=intermediate_state_indices[:batch_size],
                    a=a,
                    b=b,
                    A_log=layer.A_log,
                    dt_bias=layer.dt_bias,
                    ssm_states=ssm_states,
                    cache_indices=conv_state_indices,
                    intermediate_states_buffer=intermediate_state_cache,
                    scale=layer.head_k_dim**-0.5,
                    T=draft_token_num,
                    num_q_heads=layer.num_q_heads,
                    num_v_heads=layer.num_v_heads,
                    head_k_dim=layer.head_k_dim,
                    head_v_dim=layer.head_v_dim,
                    lower_bound=layer.lower_bound,
                )
            dense_token_indices = None
            mixed_qkv_dense = mixed_qkv.view(batch_size, draft_token_num, -1)
        else:
            # Conv update and its per-step scratch want the dense
            # [bs, draft_token_num] layout: scatter ragged tokens to their
            # step slots, gather back after (pad steps are never committed).
            # Uncovered tier-leftover tokens land in the ghost row (see
            # ragged_verify_dense_scatter_indices); their values are pad
            # garbage, discarded downstream (ghost collisions are
            # value-irrelevant).
            batch_size = query_start_loc.shape[0] - 1
            num_dense_tokens = batch_size * draft_token_num
            dense_token_indices = ragged_verify_dense_scatter_indices(
                query_start_loc=query_start_loc,
                seq_len=seq_len,
                draft_token_num=draft_token_num,
            )
            dense = mixed_qkv.new_zeros(num_dense_tokens + 1, mixed_qkv.shape[-1])
            dense.index_copy_(0, dense_token_indices, mixed_qkv)
            mixed_qkv_dense = dense[:num_dense_tokens].view(
                batch_size, draft_token_num, -1
            )

        # causal_conv1d_update expects [.., dim, width]. KDA keeps dense conv-window
        # scratch because the deduplicated overlapping layout cannot be transposed.
        mixed_qkv_reshaped = mixed_qkv_dense.transpose(1, 2)
        mixed_qkv_processed = causal_conv1d_update(
            mixed_qkv_reshaped,
            conv_states.transpose(-1, -2),
            layer.conv_weights,
            layer.bias,
            activation="silu",
            conv_state_indices=cache_indices[:batch_size],
            intermediate_conv_window=intermediate_conv_window_cache.transpose(-1, -2),
            intermediate_state_indices=intermediate_state_indices[:batch_size],
            retrieve_next_token=retrieve_next_token,
            retrieve_next_sibling=retrieve_next_sibling,
            retrieve_parent_token=retrieve_parent_token,
        )
        mixed_qkv_flat = mixed_qkv_processed.transpose(1, 2).reshape(
            batch_size * draft_token_num, -1
        )
        if dense_token_indices is None:
            mixed_qkv = mixed_qkv_flat
        else:
            # Ghost row (zeros) so uncovered tail tokens gather finite values.
            padded_flat = mixed_qkv_flat.new_zeros(
                batch_size * draft_token_num + 1, mixed_qkv_flat.shape[-1]
            )
            padded_flat[: batch_size * draft_token_num] = mixed_qkv_flat
            mixed_qkv = padded_flat[dense_token_indices]

        q, k, v = mixed_qkv.split([layer.q_dim, layer.k_dim, layer.v_dim], dim=-1)
        q = q.unflatten(-1, (-1, layer.head_q_dim)).unsqueeze(0)  # n (h d) -> 1 n h d
        k = k.unflatten(-1, (-1, layer.head_k_dim)).unsqueeze(0)
        v = v.unflatten(-1, (-1, layer.head_v_dim)).unsqueeze(0)

        # ReplaySSM: the ring-write is fused into the triton verify kernel
        # (CACHE_RING). Ragged layouts work natively -- step_idx is the
        # within-row step under varlen, so row i writes
        # ring[slot][0..verify_lens[i]) and commit folds at most commit_lens
        # of them (absorb overflow is bounded in-kernel). ring_kwargs stays
        # empty for non-triton verify kernels, which never see replayssm.
        ring_kwargs = {}
        if replayssm_rawv is not None:
            ring_kwargs = dict(
                cache_ring=True,
                replayssm_rawv=replayssm_rawv,
                replayssm_rawk=mamba_cache_params.replayssm_rawk,
                replayssm_g=mamba_cache_params.replayssm_g,
                replayssm_beta=mamba_cache_params.replayssm_beta,
            )

        core_attn_out = self.kernel_dispatcher.target_verify(
            A_log=layer.A_log,
            dt_bias=layer.dt_bias,
            q=q,
            k=k,
            v=v,
            a=a,
            b=b,
            ssm_states=ssm_states,
            cache_indices=cache_indices,
            query_start_loc=query_start_loc,
            intermediate_states_buffer=intermediate_state_cache,
            intermediate_state_indices=intermediate_state_indices,
            cache_steps=draft_token_num,
            retrieve_parent_token=retrieve_parent_token,
            lower_bound=layer.lower_bound,
            **ring_kwargs,
            **(
                dict(
                    zip(
                        ("fused_accept_state_indices", "fused_accept_num_accepted"),
                        self._fused_accept_indices(
                            cache_indices=cache_indices,
                            query_start_loc=query_start_loc,
                            intermediate_state_cache=intermediate_state_cache,
                            draft_token_num=draft_token_num,
                        ),
                    )
                )
                if self.accept_lens_pool is not None
                else {}
            ),
        )
        if dense_token_indices is not None:
            # Kernel output is empty-allocated and the capped qsl skips the
            # uncovered tail rows; zero them so discarded pad hidden states
            # stay finite. Uncovered == clamped-to-ghost.
            covered = dense_token_indices < (batch_size * draft_token_num)
            core_attn_out = torch.where(covered.view(1, -1, 1, 1), core_attn_out, 0.0)
        return core_attn_out

    def _can_run_fused_chain_verify(
        self,
        *,
        layer: RadixLinearAttention,
        mixed_qkv: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
        draft_token_num: int,
        conv_states: torch.Tensor,
        ssm_states: torch.Tensor,
        intermediate_state_cache: Optional[torch.Tensor],
        intermediate_conv_window_cache: torch.Tensor,
        cache_indices: torch.Tensor,
        intermediate_state_indices: torch.Tensor,
        retrieve_next_token: Optional[torch.Tensor],
        retrieve_next_sibling: Optional[torch.Tensor],
        retrieve_parent_token: Optional[torch.Tensor],
        replayssm_rawv: Optional[torch.Tensor],
    ) -> bool:
        if self._fused_chain_verify_fn is None or not mixed_qkv.is_cuda:
            return False
        if replayssm_rawv is not None or any(
            value is not None
            for value in (
                retrieve_next_token,
                retrieve_next_sibling,
                retrieve_parent_token,
            )
        ):
            return False
        if draft_token_num < 3 or mixed_qkv.shape[0] % draft_token_num != 0:
            return False
        if (
            not isinstance(layer.conv_weights, torch.Tensor)
            or layer.conv_weights.ndim != 2
            or layer.conv_weights.shape[1] != 4
            or layer.conv_weights.stride(1) != 1
        ):
            return False
        if (
            layer.num_q_heads != layer.num_k_heads
            or layer.head_q_dim != layer.head_k_dim
            or layer.head_k_dim & (layer.head_k_dim - 1)
        ):
            return False

        seq_len, dim = mixed_qkv.shape
        batch_size = seq_len // draft_token_num
        expected_dim = (
            2 * layer.num_q_heads * layer.head_k_dim
            + layer.num_v_heads * layer.head_v_dim
        )
        if dim != expected_dim or layer.conv_weights.shape[0] != dim:
            return False
        if layer.bias is not None and (
            not isinstance(layer.bias, torch.Tensor)
            or layer.bias.ndim != 1
            or layer.bias.shape[0] != dim
        ):
            return False
        if not isinstance(layer.A_log, torch.Tensor) or not isinstance(
            layer.dt_bias, torch.Tensor
        ):
            return False
        if (
            a.ndim == 0
            or b.ndim == 0
            or mixed_qkv.dtype not in (torch.bfloat16, torch.float16)
            or a.dtype != mixed_qkv.dtype
            or b.dtype != mixed_qkv.dtype
            or conv_states.dtype != mixed_qkv.dtype
            or intermediate_conv_window_cache.dtype != mixed_qkv.dtype
            or layer.conv_weights.dtype
            not in (torch.bfloat16, torch.float16, torch.float32)
            or (layer.bias is not None and layer.bias.dtype != layer.conv_weights.dtype)
        ):
            return False
        if (
            layer.A_log.dtype != torch.float32
            or layer.dt_bias.dtype != torch.float32
            or ssm_states.dtype != torch.float32
            or intermediate_state_cache is None
            or intermediate_state_cache.dtype != torch.float32
        ):
            return False
        if (
            mixed_qkv.stride(-1) != 1
            or a.stride(-1) != 1
            or b.stride(-1) != 1
            or not conv_states.is_contiguous()
            or not ssm_states.is_contiguous()
            or not intermediate_state_cache.is_contiguous()
        ):
            return False
        if (
            a.numel() != seq_len * layer.num_v_heads * layer.head_k_dim
            or b.numel() != seq_len * layer.num_v_heads
            or layer.A_log.numel() != layer.num_v_heads
            or layer.dt_bias.numel() != layer.num_v_heads * layer.head_k_dim
        ):
            return False
        if (
            conv_states.ndim != 3
            or tuple(conv_states.shape[-2:]) != (3, dim)
            or intermediate_conv_window_cache.ndim != 4
            or tuple(intermediate_conv_window_cache.shape[-2:]) != (3, dim)
            or ssm_states.ndim != 4
            or tuple(ssm_states.shape[-3:])
            != (layer.num_v_heads, layer.head_v_dim, layer.head_k_dim)
            or intermediate_state_cache.ndim != 5
            or intermediate_state_cache.shape[1] < draft_token_num
            or tuple(intermediate_state_cache.shape[-3:])
            != (layer.num_v_heads, layer.head_v_dim, layer.head_k_dim)
        ):
            return False
        if (
            cache_indices.ndim != 1
            or intermediate_state_indices.ndim != 1
            or cache_indices.numel() != batch_size
            or intermediate_state_indices.numel() != batch_size
            or cache_indices.dtype != torch.int32
            or intermediate_state_indices.dtype != torch.int32
        ):
            return False
        tensors = (
            layer.conv_weights,
            layer.A_log,
            layer.dt_bias,
            a,
            b,
            conv_states,
            ssm_states,
            intermediate_state_cache,
            intermediate_conv_window_cache,
            cache_indices,
            intermediate_state_indices,
        )
        if layer.bias is not None:
            tensors += (layer.bias,)
        return all(tensor.device == mixed_qkv.device for tensor in tensors)

    def _can_run_dspark_cutedsl_mtp(
        self,
        *,
        layer: RadixLinearAttention,
        mixed_qkv: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
        draft_token_num: int,
        ragged_layout,
        conv_states: torch.Tensor,
        ssm_states: torch.Tensor,
        intermediate_state_cache: torch.Tensor,
        intermediate_conv_window_cache: torch.Tensor,
        retrieve_parent_token: Optional[torch.Tensor],
        replayssm_rawv: Optional[torch.Tensor],
    ) -> bool:
        """Return whether the fixed Kimi-K3/DSpARK CuTe contract is satisfied."""
        if not self.kernel_dispatcher.verify_backend.is_nv_cutedsl() or not is_cuda():
            return False
        if importlib.util.find_spec("cutlass") is None:
            return False
        if torch.cuda.get_device_capability()[0] != 10:
            return False
        if ragged_layout is not None or retrieve_parent_token is not None:
            return False
        # draft_token_num = 1 bonus + dspark block size; the CuTe kernel is
        # specialized per block size and capped at 8 by shared-memory growth.
        if not 2 <= draft_token_num <= 8:
            return False
        if layer.bias is not None or layer.lower_bound is None:
            return False
        if (
            layer.head_q_dim != 128
            or layer.head_k_dim != 128
            or layer.head_v_dim != 128
        ):
            return False
        if (
            layer.num_q_heads != layer.num_k_heads
            or layer.num_k_heads != layer.num_v_heads
        ):
            return False
        if (
            mixed_qkv.dtype != torch.bfloat16
            or a.dtype != torch.bfloat16
            or b.dtype != torch.bfloat16
        ):
            return False
        if layer.conv_weights is None or tuple(layer.conv_weights.shape) != (
            layer.q_dim + layer.k_dim + layer.v_dim,
            4,
        ):
            return False
        if layer.conv_weights.dtype != torch.float32:
            return False
        if (
            ssm_states.dtype != torch.float32
            or tuple(ssm_states.shape[-3:])
            != (layer.num_v_heads, layer.head_v_dim, layer.head_k_dim)
            or tuple(ssm_states.stride()[-3:])
            != (
                layer.head_v_dim * layer.head_k_dim,
                layer.head_k_dim,
                1,
            )
            or ssm_states.stride(0) % 4 != 0
            or ssm_states.storage_offset() % 4 != 0
        ):
            return False
        if conv_states.shape[-2] != 3 or intermediate_conv_window_cache.shape[-2] != 3:
            return False
        if intermediate_state_cache is None:
            # ReplaySSM: the ring replaces the per-step snapshots. The kernel
            # wrapper validates ring layout/dtypes and raises loudly (there is
            # no recurrent fallback without intermediate_ssm).
            return replayssm_rawv is not None
        if intermediate_state_cache.shape[1] < draft_token_num:
            return False
        if tuple(intermediate_state_cache.shape[-3:]) != (
            layer.num_v_heads,
            layer.head_v_dim,
            layer.head_k_dim,
        ):
            return False
        return True

    @staticmethod
    def _run_dspark_cutedsl_mtp(
        *,
        layer: RadixLinearAttention,
        mixed_qkv: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
        conv_states: torch.Tensor,
        ssm_states: torch.Tensor,
        intermediate_state_cache: torch.Tensor,
        intermediate_conv_window_cache: torch.Tensor,
        intermediate_state_indices: torch.Tensor,
        cache_indices: torch.Tensor,
        query_start_loc: torch.Tensor,
        replayssm_rawv: Optional[torch.Tensor] = None,
        replayssm_rawk: Optional[torch.Tensor] = None,
        replayssm_g: Optional[torch.Tensor] = None,
        replayssm_beta: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        from sglang.kernels.ops.kimi_k3.kda_decode_mtp import (
            fused_kda_decode_mtp_dspark,
        )

        seq_len = mixed_qkv.shape[0]
        h = layer.num_v_heads
        x_q, x_k, x_v = mixed_qkv.split([layer.q_dim, layer.k_dim, layer.v_dim], dim=-1)
        x_q = x_q.reshape(1, seq_len, h, layer.head_q_dim)
        x_k = x_k.reshape(1, seq_len, h, layer.head_k_dim)
        x_v = x_v.reshape(1, seq_len, h, layer.head_v_dim)
        w_q, w_k, w_v = layer.conv_weights.split(
            [layer.q_dim, layer.k_dim, layer.v_dim], dim=0
        )
        cs_q, cs_k, cs_v = conv_states.split(
            [layer.q_dim, layer.k_dim, layer.v_dim], dim=-1
        )
        cs_q = cs_q.transpose(-1, -2)
        cs_k = cs_k.transpose(-1, -2)
        cs_v = cs_v.transpose(-1, -2)
        intermediate_conv_window_cache = intermediate_conv_window_cache.transpose(
            -1, -2
        )
        ic_q, ic_k, ic_v = intermediate_conv_window_cache.split(
            [layer.q_dim, layer.k_dim, layer.v_dim], dim=-2
        )
        # The kernel owns all 128 output channels and can fold gated RMSNorm
        # into the recurrence.
        onorm_gate = getattr(layer, "_k3_onorm_gate", None)
        fused_static = getattr(layer, "_k3_fused_decode_args", None)
        apply_onorm = onorm_gate is not None and fused_static is not None
        if apply_onorm:
            onorm_weight = fused_static[5]
            onorm_eps = fused_static[6]
            onorm_gate = onorm_gate.reshape(1, seq_len, h, layer.head_v_dim)
        else:
            onorm_weight = None
            onorm_eps = None
            onorm_gate = None

        out = fused_kda_decode_mtp_dspark(
            x_q=x_q,
            x_k=x_k,
            x_v=x_v,
            w_q=w_q,
            w_k=w_k,
            w_v=w_v,
            cs_q=cs_q,
            cs_k=cs_k,
            cs_v=cs_v,
            g=a,
            beta=b,
            A_log=layer.A_log.reshape(-1),
            dt_bias=layer.dt_bias.reshape(-1),
            recurrent_state=ssm_states,
            intermediate_ssm=intermediate_state_cache,
            intermediate_state_indices=intermediate_state_indices,
            intermediate_conv_q=ic_q,
            intermediate_conv_k=ic_k,
            intermediate_conv_v=ic_v,
            ssm_state_indices=cache_indices.to(torch.int32),
            cu_seqlens=query_start_loc.to(torch.int32),
            lower_bound=float(layer.lower_bound),
            scale=layer.head_q_dim**-0.5,
            replayssm_rawv=replayssm_rawv,
            replayssm_rawk=replayssm_rawk,
            replayssm_g=replayssm_g,
            replayssm_beta=replayssm_beta,
            onorm_gate=onorm_gate,
            onorm_weight=onorm_weight,
            onorm_eps=onorm_eps,
        )
        if apply_onorm:
            layer._k3_onorm_consumed = True
        return out
