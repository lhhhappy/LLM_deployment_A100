from pathlib import Path
Path('outputs').mkdir(exist_ok=True)
print('Playground bundle contains submitted outputs.')
