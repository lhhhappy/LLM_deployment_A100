// ax-scale-fold-probe native 1fec70021765fb32becf11d8b30773eab91e9ea0f14ec64247e90d8f75396102

#include <cuda_bf16.h>
extern "C" __global__ void ax_scale_intrinsics(
    const unsigned short* scales, unsigned int* output, unsigned int scale_count) {
  const unsigned int index = blockIdx.x * blockDim.x + threadIdx.x;
  if (index >= scale_count * 256) return;
  const unsigned int q = index % 256;
  // Exactly the BF16 bits returned by FP8 bit-field dequantization before
  // mainloop_arith's fixed exponent correction. Exclude FP8 NaN on the host.
  const unsigned int raw16 = ((q & 128) << 8) | ((q & 127) << 4);
  const unsigned int raw_bits = raw16 | (raw16 << 16);
  const unsigned int scale16 = scales[index / 256];
  const unsigned int scale_bits = scale16 | (scale16 << 16);
  const unsigned int factor_bits = 0x7b807b80U;  // BF16 pair 2^120
  const auto raw = *reinterpret_cast<const __nv_bfloat162*>(&raw_bits);
  const auto scale = *reinterpret_cast<const __nv_bfloat162*>(&scale_bits);
  const auto factor = *reinterpret_cast<const __nv_bfloat162*>(&factor_bits);
  auto corrected = __hmul2(raw, factor);
  auto biased = __hmul2(scale, factor);
  auto corrected_bits = *reinterpret_cast<unsigned int*>(&corrected);
  auto biased_bits = *reinterpret_cast<unsigned int*>(&biased);
  // Prevent reassociation/CSE across the explicit native rounding boundary.
  asm volatile("" : "+r"(corrected_bits), "+r"(biased_bits));
  corrected = *reinterpret_cast<const __nv_bfloat162*>(&corrected_bits);
  biased = *reinterpret_cast<const __nv_bfloat162*>(&biased_bits);
  const auto native_value = __hmul2(corrected, scale);
  const auto fold_value = __hmul2(raw, biased);
  output[index * 2] = *reinterpret_cast<const unsigned int*>(&native_value);
  output[index * 2 + 1] = *reinterpret_cast<const unsigned int*>(&fold_value);
}
